<?php

namespace Riza\EcoApiScorePremium;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\entity\Entity;
use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;
use pocketmine\utils\Config;

use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerJoinEvent;

use Riza\EcoApiScorePremium\ScoreHud\TagResolveListener;
use Ifera\ScoreHud\ScoreHud;
use Ifera\ScoreHud\event\PlayerTagsUpdateEvent;
use Ifera\ScoreHud\scoreboard\ScoreTag;
use pocketmine\scheduler\ClosureTask;

class Main extends PluginBase implements Listener{

    public $ecoapi;
    
    public function onEnable() : void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if($this->eco == null){
            $this->eco->disablePlugin();
            $this->getLogger()->alert("EconomyAPI not found!");
        }
        // ScoreHud
		if(class_exists(ScoreHud::class)){
			$this->getScheduler()->scheduleRepeatingTask(new ClosureTask(
            	function(): void {
               	 foreach ($this->getServer()->getOnlinePlayers() as $player) {
              	      if (!$player->isOnline()) {
                     	   continue;
               	     }

                	   (new PlayerTagsUpdateEvent($player, [
					       new ScoreTag("ecoapi.premium", (string) "" . $this->converterMoney($this->eco->myMoney($player)))
					   ]))->call();
                	}
         	   }
			), 1);
			$this->getServer()->getPluginManager()->registerEvents(new TagResolveListener($this), $this);
		}
    }
    
    public function converterMoney($n, $precision = 1)
    {
        if ($n < 999) {
            // 0 - 900
            $n_format = number_format($n, $precision);
            $suffix = 'c';
        } else if ($n < 999999) {
            // 0.9k-850k
            $n_format = number_format($n / 1000, $precision);
            $suffix = 'K';
        } else if ($n < 999999999) {
            // 0.9m-850m
            $n_format = number_format($n / 1000000, $precision);
            $suffix = 'M';
        } else if ($n < 999999999999) {
            // 0.9b-850b
            $n_format = number_format($n / 1000000000, $precision);
            $suffix = 'B';
        } else {
            // 0.9t+
            $n_format = number_format($n / 1000000000000, $precision);
            $suffix = 'T';
        }
        if ($precision > 0) {
            $dotzero = '.' . str_repeat('0', $precision);
            $n_format = str_replace($dotzero, '', $n_format);
        }

        return $n_format . $suffix;
    }
}
